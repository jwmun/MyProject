# Write your own image captiong code
# You can modify the class structure
# and add additional function needed for image captionging

import tensorflow as tf
import numpy as np


class Captioning():
	
	def __init__(self):
		self._start = 1


	def build_model(self):
		loss = 0


	def predict(self):
		captions = None


